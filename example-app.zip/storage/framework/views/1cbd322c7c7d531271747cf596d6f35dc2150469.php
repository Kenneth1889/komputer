<?php $__env->startSection('main-content'); ?>
  <section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
    </div>
    <div class="card">
      <div class="card-header">
        <a href="<?php echo e(route("create")); ?>" role="button" class="btn btn-success">Add New Items</a>
      </div>
      <div class="card-body p-4">
        <table class="table table-striped" id="tbl-adm-category">
          <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Photo</th>
            <th>Price</th>
            <th>Description</th>
            <th>Category</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($item->id); ?></td>
              <td><?php echo e($item->name); ?></td>
              <td><?php echo e($item->photo); ?></td>
              <td><?php echo e($item->price); ?></td>
              <td><?php echo e($item->description); ?></td>
              <td><?php echo e($item->category->id); ?> - <?php echo e($item->category->name); ?>

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
    </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\web-pnext-20241-main\resources\views/adm-item/index.blade.php ENDPATH**/ ?>