<footer class="py-5 bg-dark">
  <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website
      2023</p></div>
</footer>
<?php /**PATH C:\Users\Kenneth\example-app\resources\views/layouts/footer.blade.php ENDPATH**/ ?>