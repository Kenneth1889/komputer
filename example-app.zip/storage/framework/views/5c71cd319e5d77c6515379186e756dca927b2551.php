<?php $__env->startSection('main-content'); ?>
  <section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
      <div class="card">
        <div class="card-body p-4">
          <form method="post" action="<?php echo e(route('cat-update', ['category'=> $category->id])); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="name">Category Name</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Enter new category name" autofocus required value="<?php echo e($category->name); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
          </form>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kenneth\example-app\resources\views/adm-category/edit.blade.php ENDPATH**/ ?>