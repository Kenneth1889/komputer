

<?php $__env->startSection('content'); ?>
    <div class="album py-5 bg-body-tertiary">
        <div class="container">

            <div class="row p-4">
                <a href="<?php echo e(route('siswa-index')); ?>" role="button" class="btn btn-warning">Back to Students List</a>
            </div>

            <form>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nisId">Student ID</label>
                    <input type="text" class="form-control" id="nisId" placeholder="Student ID" name="nis" maxlength="10" autofocus required>
                </div>
                <div class="form-group">
                    <label for="nameId">Name</label>
                    <input type="text" class="form-control" id="nameId" placeholder="Student's Name" name="nama" required>
                </div><div class="form-group">
                    <label for="image">Post Image</label>
                    <input type="file" class="form-control" id="image" placeholder="Student's Image" name="nama" required>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-css'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMAK2\elmo_project\resources\views/siswa/create.blade.php ENDPATH**/ ?>