<?php $__env->startSection('main-content'); ?>
  <section class="py-5">
    <div class="card">
      <div class="card-header">
        <a href="<?php echo e(route("buat")); ?>" role="button" class="btn btn-success">Add New Category </a>
      </div>
      <div class="card-body p-4">
        <table class="table table-striped" id="tbl-adm-category">
          <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($category->id); ?></td>
              <td><?php echo e($category->name); ?></td>
              <td>
                <a href ="<?php echo e(route('cat-edit', ['category'=> $category->id])); ?>" class="btn btn-info" role="button">Edit</a>
              </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
    </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kenneth\example-app\resources\views/adm-category/index.blade.php ENDPATH**/ ?>