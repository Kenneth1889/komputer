<?php $__env->startSection('main-content'); ?>
  <section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
      <div class="card">
        <div class="card-body p-4">
          <form method="post" action="<?php echo e(route('toko')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="name">Category Name</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Enter new item name" autofocus required>
            </div>
            <div class="form-group">
              <label for="photo">Photo</label>
              <input type="text" class="form-control" id="Photo" name="photo" placeholder="Enter new Photo" autofocus required>
            </div>
            <div class="form-group">
              <label for="price">Price</label>
              <input type="text" class="form-control" id="Price" name="price" placeholder="200,000" min="0" autofocus required>
            </div>
            <div class="form-group">
              <label for="description">Description</label>
              <input type="text" class="form-control" id="Description" name="Description" placeholder="Enter your description" autofocus required>
            </div>

            <div class="form-group m-1 mb-2"> </div>
            <label for="description">Category</label>
            <select class="form-select" aria-label="category" name="category_id" required>
              <option selected>Open this select menu</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->id); ?> - <?php echo e($category->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projek\web-pnext-20241-main\resources\views/adm-item/create.blade.php ENDPATH**/ ?>